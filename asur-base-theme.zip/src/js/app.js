import * as bootstrap from 'bootstrap'
import { createIcons, icons } from 'lucide';


document.addEventListener('DOMContentLoaded', () => {
    createIcons({ icons });
});
console.log('App JS loaded');




