<footer class="container py-5 border-top text-center">
  <p class="mb-0">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>.</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
