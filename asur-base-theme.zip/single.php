<?php get_header(); ?>
<main class="container py-5">
  <h1><?php the_title(); ?></h1>
  <?php the_content(); ?>
</main>
<?php get_footer(); ?>
