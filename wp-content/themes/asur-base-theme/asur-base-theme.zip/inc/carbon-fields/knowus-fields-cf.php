<?php

use Carbon_Fields\Container;
use Carbon_Fields\Field;

Container::make('post_meta', 'Contenido de Know Us')
    ->where('post_id', '=', get_page_id_by_slug('know-us'))
    ->add_fields([

        Field::make('separator', 'crb_knowus_separator_01', 'company Team carousel'),
        Field::make('text', 'over-title', 'sobre título'),
        Field::make('text', 'title', 'Título'),


        Field::make('complex', 'crb_knowus_team', 'Integrantes del equipo')
            ->add_fields([
                Field::make('text', 'name', 'Nombre'),
                Field::make('rich_text', 'description', 'Cargo o descripción'),
                Field::make('image', 'photo', 'Foto del miembro')
                    ->set_value_type('url'),
            ])
            ->set_layout('tabbed-horizontal'),


        Field::make('separator', 'crb_knowus_separator_02', 'company Team Picture'),


        Field::make('select', 'crb_company_op', 'Nivel de opacidad')
            ->add_options([
                '' => 'Selecciona una opacidad',
                'opacity-25' => '25%',
                'opacity-50' => '50%',
                'opacity-75' => '75%',
                'opacity-100' => '100%',
            ])
            ->set_default_value('opacity-25')
            ->set_width(33),
        Field::make('color', 'crb_company_bg', 'Color de fondo')
            ->set_palette(['#ffffff', '#000000', '#162944'])
            ->set_help_text('Este color se usará como mascara de fondo ')
            ->set_default_value('#162944')
            ->set_width(33),
        Field::make('image', 'crb_company_img', 'Imagen de equipo')
            ->set_value_type('url')
            ->set_width(33),
    ]);






Container::make('post_meta', 'service cycle')
    ->where('post_id', '=', get_page_id_by_slug('know-us'))
    ->add_fields([
        Field::make('association', 'selected_service_cycle', 'Seleccionar service cycle')
            ->set_types([
                [
                    'type' => 'post',
                    'post_type' => 'service-cycle'
                ]
            ])
            ->set_duplicates_allowed(false)
            ->set_help_text('Selecciona los service-cycle  que se mostrarán en esta página.')
    ]);

Container::make('post_meta', 'presence')
    ->where('post_id', '=', get_page_id_by_slug('know-us'))
    ->add_fields([
        Field::make('association', 'selected_presences', 'Seleccionar presences')
            ->set_types([
                [
                    'type' => 'post',
                    'post_type' => 'presence'
                ]
            ])
            ->set_duplicates_allowed(false)
            ->set_help_text('Selecciona los  que se mostrarán en esta página.')
    ]);
